import java.util.ArrayList;

import javax.swing.ImageIcon;
import java.awt.Image;
public class Pipe {
    // Declare instance variables
    private Pipe leftConnect, rightConnect, upConnect, downConnect;
    private boolean hasWater;
    private boolean willHaveWater = false;
    public enum Type
    {
        TWO,
        CORNER,
        THREE,
        FOUR,
        END,
        SOURCE,
    }
    public enum Direction
    {
        LEFT,
        RIGHT,
        UP,
        DOWN,
    }

    private Type type;
    private Direction dir;

    public Pipe(boolean water, String pipeType, String pipeDirection)
    {
        this.hasWater = water;
        this.type = Type.valueOf(pipeType.toUpperCase());
        this.dir = Direction.valueOf(pipeDirection.toUpperCase());
    }

    // Setters and getters for private fields
    public void setWater(boolean water) { this.hasWater = water; }
    public boolean getWater() { return this.hasWater; }
    public void setWillHaveWater(boolean water) {   this.willHaveWater = water; }
    public boolean getWillHaveWater() { return this.willHaveWater; }
    // public void setType(String pipeType) { this.type = Type.valueOf(pipeType.toUpperCase()); }
    public String getType() { return String.valueOf(this.type); }

    // Setter for pipe connections
    public void setConnect(String direction, Pipe pipe)
    {
        switch (direction.toUpperCase())
        {
            case "LEFT":
                this.leftConnect = pipe;
                break;
            case "RIGHT":
                this.rightConnect = pipe;
                break;
            case "UP":
                this.upConnect = pipe;
                break;
            case "DOWN":
                this.downConnect = pipe;
                break;
            default:
                throw new Error("Invalid pipe direction: " + direction);
        }
    }
    // Getters for pipe connections
    public Pipe getConnect(String direction)
    {
        switch (direction.toUpperCase())
        {
            case "LEFT":
                return this.leftConnect;
            case "RIGHT":
                return this.rightConnect;
            case "UP":
                return this.upConnect;
            case "DOWN":
                return this.downConnect;
            default:
                throw new Error("Invalid pipe direction: " + direction);
        }
    }
    public boolean hasConnect(String direction)
    {
        switch (direction.toUpperCase())
        {
            case "LEFT":
                return (this.leftConnect != null);
            case "RIGHT":
                return (this.rightConnect != null);
            case "UP":
                return (this.upConnect != null);
            case "DOWN":
                return (this.downConnect != null);
            default:
                throw new Error("Invalid pipe direction: " + direction);
        }
    }
    public int countConnections()
    {
        int count = 0;
        if (this.leftConnect != null) count++;
        if (this.rightConnect != null) count++;
        if (this.upConnect != null) count++;
        if (this.downConnect != null) count++;
        return count;
    }
    public ArrayList<Pipe> getAllConnections()
    {
        ArrayList<Pipe> out = new ArrayList<>();

        if (this.leftConnect != null) out.add(this.leftConnect);
        if (this.rightConnect != null) out.add(this.rightConnect);
        if (this.upConnect != null) out.add(this.upConnect);
        if (this.downConnect != null) out.add(this.downConnect);

        return out;
    }

    public static void flow(Pipe pipe)
    {
        boolean canFlow = false;
        int connections = 0;
        if (pipe == null)
        {
            canFlow = false;
        }
        else if (pipe.getType().equals("END"))
        {
            canFlow = false;
        }
        else
        {
            canFlow = pipe.getWater();
            connections = pipe.getAllConnections().size();
        }
        for (int i = 0; i < connections && canFlow; i++)
        {
            Pipe connect = pipe.getAllConnections().get(i);
            if (connect == null) throw new Error("connect == null");
            connect.setWillHaveWater(true);
        }
    }

    public Image getImage(int width, int height)
    {
        ImageIcon img;
        int order = 0;
        switch (this.type)
        {
            case TWO:
                order = 3;
                break;
            case CORNER:
                order = 5;
                break;
            case THREE:
                order = 7;
                break;
            case FOUR:
                order = 9;
                break;
            case END:
                order = 1;
                break;
            case SOURCE:
                order = -1; // Source.hasWater = true; -1 + 1 = 0
                break;
            default:
                break;
        }
        int fill = this.hasWater ? 1 : 0;

        int number = order + fill;
        if (number < 10)
        {
            img = new ImageIcon("./PipeLight/pipe_0" + number + ".png");
        }
        else
        {
            img = new ImageIcon("./PipeLight/pipe_" + number + ".png");
        }
        img.setImage(img.getImage().getScaledInstance(width, height, Image.SCALE_FAST));
        return img.getImage();
    }

    public int getTrans()
    {
        int trans = 0;

        // This is some evil trickery that shouldn't be allowed
        switch (this.type)
        {
            case TWO:
                trans = 0b11111111_00000000_11111111_00000000;
                break;
            case CORNER:
                trans = 0b11111111_00000000_00000000_11111111;
                break;
            case THREE:
                trans = 0b11111111_11111111_00000000_11111111;
                break;
            case FOUR:
                trans = 0b11111111_11111111_11111111_11111111;
                return trans;
            case SOURCE:
            case END:
                trans = 0b11111111_00000000_00000000_00000000;
                break;
            default:
                trans = 0b00000000_00000000_00000000_00000000;
                break;
        }

        switch (this.dir)
        {
            case LEFT:
                trans = (trans >>> 24) | (trans << 8); // Turn -90 degrees
                break;
            case RIGHT:
                trans = (trans >>> 8) | (trans << 24); // Turn 90 degrees
                break;
            case UP:
                return trans; // Should do nothing (trans) | (trans) can != (trans) ???
            case DOWN:
                trans = (trans >>> 16)| (trans << 16); // Flip 180 degrees
                break;
            default:
                return trans; // Should do nothing (trans) | (trans) can != (trans) ???
        }

        return trans;
    }

    public double getAngle()
    {
        switch (this.dir)
        {
            case LEFT:
                return Math.toRadians(-90.0);
            case RIGHT:
                return Math.toRadians(90.0);
            case UP:
                return 0.0;
            case DOWN:
                return Math.toRadians(180.0);
            default:
                return 0.0;
        }
    }
}