public class Main
{
    public Main()
    {
       new PipeNetwork();
    }

    

    public static void main(String[] args)
    {
        new Main();
    }
}