public class Source extends Pipe{
    public Source(String sourceDirection)
    {
        super(true, "SOURCE", sourceDirection);
    }

    public java.awt.Image getImage(int width, int height)
    {
        javax.swing.ImageIcon img = new javax.swing.ImageIcon("./PipeLight/pipe_00.png");
        img.setImage(img.getImage().getScaledInstance(width, height, java.awt.Image.SCALE_FAST));
        return img.getImage();
    }
}
