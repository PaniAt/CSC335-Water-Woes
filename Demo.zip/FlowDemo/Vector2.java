/*
 * This will not be a standard Vector2 class, because I need it to follow
 * some specifics of my program.
 * Will I need to take the dot product? No!
 * Will I need to take the cross product? No!
 */
public class Vector2
{
    public int x;
    public int y;

    /**
     * Constructor for vectors
     * 
     * @param xParam - Integer x position
     * @param yParam - Integer y position
     */
    public Vector2(int xParam, int yParam)
    {
        this.x = xParam;
        this.y = yParam;
    }

    /**
     * Adds two vectors
     * 
     * @param vector - Vector2 to add
     * @return Sum of coordinates of two vectors
     */
    public Vector2 add(Vector2 vector)
    {
        return new Vector2(this.x + vector.x, this.y + vector.y);
    }

    /**
     * Subtracts two vectors
     * 
     * @param vector - Vector2 to subtract
     * @return Difference of coordinates of two vectors
     */
    public Vector2 sub(Vector2 vector)
    {
        return new Vector2(this.x - vector.x, this.y - vector.y);
    }

    /**
     * Negates this vector. Acts the same way as the unary minus
     * symbol in front of a number/variable
     * 
     * @return Vector with coordinates multiplied by -1
     */
    public Vector2 neg()
    {
        return new Vector2(-this.x, -this.y);
    }

    /**
     * Finds vector that is rotated 90 degrees from this vector.
     * This new vector is to the left of the current vector if the
     * observer were at (0, 0) looking towards this vector. Flip this
     * vector with the {@code negate} function to make it "right"
     * 
     * @return Vector with -y as x coordinate and x as y coordinate.
     */
    public Vector2 rot()
    {
        return new Vector2(-this.y, this.x);
    }

    /**
     * Returns the biggest length of the vector. If the x length is
     * larger than the y length, a vector with only x. If the y
     * length is larger than the x length, a vector with only y. If
     * the two vectors are equal, returns the x length.
     * 
     * @return Vector of only largest length
     */
    public Vector2 mag()
    {
        if (abs(this.x) < abs(this.y))
        {
            return new Vector2(0, this.y);
        }
        else
        {
            return new Vector2(this.x, 0);
        }
    }


    private static int abs(int a)
    {
        return (a < 0) ? -a : a;
    }
}
