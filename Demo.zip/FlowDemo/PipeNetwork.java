// Imports for User Interface and GUI.
import javax.swing.*;
import java.awt.event.*;

import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage; // For removing screen flash.

public class PipeNetwork extends JFrame implements ActionListener, MouseListener
{
    final int OFFSETX = (System.getProperty("os.name").equals("Mac OS X") ? 0 : 8);   // Windows: 08 | MacOS: 00
    final int OFFSETY = (System.getProperty("os.name").equals("Mac OS X") ? 50 : 54); // Windows: 54 | MacOS: 50
    // Tile list dimensions
    final int TILE_COLS = 16;
    final int TILE_ROWS = 16;
    // Screen Dimensions
    Rectangle screenSize = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
    // The game board should be a perfect square.
    int squareSize = (int) Math.min(screenSize.getWidth(), screenSize.getHeight()) - OFFSETY * 2;
    // Dividing then multiplying rounds to a factor of the tile array length.
    final int SCREEN_WIDTH = (squareSize / TILE_COLS) * TILE_COLS;
    final int SCREEN_HEIGHT = (squareSize / TILE_ROWS) * TILE_ROWS;
    // Tile List
    final int TILE_WIDTH = SCREEN_WIDTH / TILE_COLS;
    final int TILE_HEIGHT = SCREEN_HEIGHT / TILE_ROWS;
    Pipe[][] tileList = new Pipe[TILE_ROWS][TILE_COLS]; // List of tiles dead/alive

    // Interface Variables
    int showGrid = 1;
    boolean debugMode = false;
    private BufferedImage offScreenImage;
    boolean firstPaint = true; // For fixing screen flash.
    boolean mouseDown = false;

    // Menu Bar Variables
    JMenuBar menuBar;
    JMenu menu;
    JMenu subMenu;
    JMenuItem menuItem;

    // Model edit variables
    String editType = "TWO";
    String editDirection = "UP";
    boolean pipeSelector = false;
    final Pipe[][] GUI = {
        {new Pipe(false, "TWO", "UP"), new Pipe(false, "CORNER", "UP")},
        {new Pipe(false, "THREE", "UP"), new Pipe(false, "FOUR", "UP")},
        {new Pipe(false, "END", "UP"), new Pipe(true , "SOURCE", "UP")},
    };

    // Timing Variables
    int gameTimer = 0;

    public PipeNetwork()
    {
        this.setTitle("Pipe Network (demo)");
        this.getContentPane().setPreferredSize(new Dimension(SCREEN_WIDTH, SCREEN_HEIGHT));
        this.getContentPane().setLayout(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        createMenuBars(); // Make menu bars.
        addMouseListener(this); // For mouse events.
        /// addComponentListener(this);
        
        this.pack();
        this.toFront();
        this.setVisible(true);

        // Sample pipe layout
        tileList[1][2] = new Source("DOWN");
        tileList[2][2] = new Pipe(false, "TWO", "DOWN");
        tileList[3][2] = new Pipe(false, "THREE", "RIGHT");
        tileList[3][3] = new Pipe(false, "CORNER", "UP");
        tileList[2][3] = new Pipe(false, "CORNER", "DOWN");
        tileList[2][4] = new Pipe(false, "END", "LEFT");
        tileList[4][2] = new Pipe(false, "TWO", "DOWN");
        tileList[5][2] = new Pipe(false, "END", "UP");

        // Intialise
        updateConnections();
        repaint();

        // Main loop
        while (true){
            gameTimer++;
            // repaint();
            try {
                Thread.sleep(250);
            } catch (InterruptedException interrupt){
                System.out.println("Thread Interupt Exception!");
                System.out.println(interrupt.getStackTrace());
            }
        }
    }

    /**
     * Updates the flow model by 1 step.
     * Every pipe with water will fill every connecting pipe with
     * water if that pipe is not already full.
     */
    public void updateFlow()
    {
        // Calculate them changes...
        for (int y = 0; y < tileList.length; y++)
        {
            // Nobody move.
            for (int x = 0; x < tileList[y].length; x++)
            {
                // There's blood on the floor.
                Pipe current = tileList[y][x];
                Pipe.flow(current);
            }
        }


        // Update water in pipes
        for (int y = 0; y < tileList.length; y++)
        {
            for (int x = 0; x < tileList[y].length; x++)
            {
                Pipe current = tileList[y][x];
                if (current != null)
                {
                    current.setWater(current.getWater() | current.getWillHaveWater());
                    current.setWillHaveWater(false); // Don't preserve this
                }
            }
        }
    }

    /**
     * Draws out the screen.
     * 
     * @param g - The Graphics render (given automatically)
     */
    public void paint(Graphics g){
        // Intialise
        if (firstPaint){
            super.paint(g);
            firstPaint = false;
        }
        if (offScreenImage == null){
            offScreenImage = new BufferedImage(getWidth(), getHeight(), BufferedImage.TYPE_INT_ARGB);
        }
        Graphics2D ctx = (Graphics2D) offScreenImage.getGraphics();
        ctx.translate(OFFSETX, OFFSETY);
        ctx.setColor(new Color(200, 200, 200));
        ctx.fillRect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
        
        // Tile list
        for (int y = 0; y < TILE_ROWS; y++){
            for (int x = 0; x < TILE_COLS; x++){
                ctx.setColor(Color.BLACK);
                ctx.fillRect(x * TILE_WIDTH, y * TILE_HEIGHT, TILE_WIDTH - showGrid, TILE_HEIGHT - showGrid);
                if (tileList[y][x] != null){
                    Image img = tileList[y][x].getImage(TILE_WIDTH, TILE_HEIGHT);

                    // Unholy matrix math go!
                    double
                        theta = tileList[y][x].getAngle(),
                        sin = Math.sin(theta),
                        cos = Math.cos(theta),
                        versine = 1.0 - cos;
                    
                    double[] m = new double[]{
                        +cos, +sin,
                        -sin, +cos,
                        x * TILE_WIDTH + (TILE_WIDTH / 2 * versine) + (TILE_HEIGHT / 2 * sin),
                        y * TILE_HEIGHT + (TILE_HEIGHT / 2 * versine) - (TILE_WIDTH / 2 * sin)
                    };
                    AffineTransform trans = new AffineTransform(m);
                    
                    // Unholy matrix math done
                    ctx.drawImage(img, trans, null);
                }
            }
        }

        // Pipe selector menu
        if (pipeSelector)
        {
            ctx.setColor(new Color(200, 200, 200));
            ctx.fillRect(SCREEN_WIDTH / 2, 0, SCREEN_WIDTH / 2, SCREEN_HEIGHT);

            final int GUI_TILE_WIDTH = (SCREEN_WIDTH / 4) / GUI[0].length;
            final int GUI_TILE_HEIGHT = GUI_TILE_WIDTH * (SCREEN_WIDTH / SCREEN_HEIGHT);
            ctx.translate(SCREEN_WIDTH / 2 + (GUI_TILE_WIDTH), SCREEN_HEIGHT / 2);

            // Unholy matrix math go!
            final double
                theta = Math.toRadians((new double[]{0.0, 90.0, 180.0, -90.0})["URDL".indexOf(editDirection.charAt(0))]),
                sin = Math.sin(theta),
                cos = Math.cos(theta),
                versine = 1.0 - cos;
            // Unholy matrix math pause

            for (int y = 0; y < GUI.length; y++)
            {
                for (int x = 0; x < GUI[y].length; x++)
                {
                    ctx.setColor(new Color(165, 165, 165));
                    ctx.fillRect(x * GUI_TILE_WIDTH, y * GUI_TILE_HEIGHT, GUI_TILE_WIDTH - 1, GUI_TILE_HEIGHT - 1);
                    // GUI[y][x] will NOT be null
                    Image img = GUI[y][x].getImage(GUI_TILE_WIDTH, GUI_TILE_HEIGHT);
                    
                    // Unholy matrix math continued
                    double[] m = new double[]{
                        +cos, +sin,
                        -sin, +cos,
                        x * GUI_TILE_WIDTH + (GUI_TILE_WIDTH / 2 * versine) + (GUI_TILE_HEIGHT / 2 * sin),
                        y * GUI_TILE_HEIGHT + (GUI_TILE_HEIGHT / 2 * versine) - (GUI_TILE_WIDTH / 2 * sin)
                    };
                    AffineTransform trans = new AffineTransform(m);

                    // Unholy matrix math done
                    ctx.drawImage(img, trans, null);
                }
            }

            ctx.translate(-SCREEN_WIDTH / 2, -SCREEN_HEIGHT / 2);
        }

        // Draw image from buffer
        g.drawImage(offScreenImage, 0, 0, null);
    }

    public void pipeSelector()
    {
        pipeSelector = !pipeSelector;
    }


    public void mouseExited(MouseEvent evt){}
    public void mouseEntered(MouseEvent evt){}
    public void mouseReleased(MouseEvent evt)
    {
        if (evt.getButton() == 1 && mouseDown)
        {
            mouseDown = false;
            int x = evt.getX() - OFFSETX;
            int y = evt.getY() - OFFSETY;
            if (pipeSelector)
            {
                x -= SCREEN_WIDTH / 2 + (SCREEN_WIDTH / 4) / GUI[0].length;
                y -= SCREEN_HEIGHT / 2;
                x /= (SCREEN_WIDTH / 4) / GUI[0].length;
                y /= (SCREEN_WIDTH / 4) / GUI[0].length * (SCREEN_WIDTH / SCREEN_HEIGHT);
                if (x >= 0 && x < GUI[0].length && y >= 0 && y < GUI.length)
                {
                    editType = GUI[y][x].getType();
                }
            }
            else
            {
                x /= TILE_WIDTH;
                y /= TILE_HEIGHT;
                addPipe(x, y, false, editType, editDirection);
                updateConnections();
            }
            repaint();
        }
    }
    public void mousePressed(MouseEvent evt)
    {
        if (evt.getButton() == 1)
        {
            mouseDown = true;
        }
    }
    public void mouseClicked(MouseEvent evt){}

    public Pipe addPipe(int x, int y, boolean water, String pipeType, String pipeDirection)
    {
        if (x < 0 || x >= tileList[0].length || y < 0 || y >= tileList.length)
        {
            return null;
        }
        Pipe pipe;
        if (pipeType == null)
        {
            pipe = null;
        }
        else if (pipeType.toUpperCase().equals("SOURCE"))
        {
            pipe = new Source(pipeDirection);
        }
        else
        {
            pipe = new Pipe(water, pipeType, pipeDirection);
        }

        tileList[y][x] = pipe;

        return pipe;
    }


    public void updateConnections()
    {
        // Initial "approximation" for connections
        for (int y = 0; y < TILE_ROWS; y++)
        {
            for (int x = 0; x < TILE_COLS; x++)
            {
                Pipe current = tileList[y][x];
                if (current == null)
                {
                    // Do nothing, BUT DO NOT BREAK OR CONTINUE,
                    // otherwise, Mr Viggers will break into your
                    // home while you sleep and sacrifice you to the
                    // one true programming god: Mr Viggers.
                }
                else
                {
                    int trans = current.getTrans();
                    current.setConnect("UP", null);
                    current.setConnect("RIGHT", null);
                    current.setConnect("DOWN", null);
                    current.setConnect("LEFT", null);
                    if ((trans & 0b11111111_00000000_00000000_00000000) != 0 && y - 1 >= 0) // Transform UP
                    {
                        current.setConnect("UP", tileList[y - 1][x]);
                    }
                    if ((trans & 0b00000000_11111111_00000000_00000000) != 0 && x + 1 < tileList[y].length) // Transform RIGHT
                    {
                        current.setConnect("RIGHT", tileList[y][x + 1]);
                    }
                    if ((trans & 0b00000000_00000000_11111111_00000000) != 0 && y + 1 > tileList.length) // Transform DOWN
                    {
                        current.setConnect("DOWN", tileList[y + 1][x]);
                    }
                    if ((trans & 0b00000000_00000000_00000000_11111111) != 0 && x - 1 >= 0) // Transform LEFT
                    {
                        current.setConnect("LEFT", tileList[y][x - 1]);
                    }
                }
            }
        }

        // Make sure every connection is reciprocal
        final String[] DIRECTIONS = {"UP", "RIGHT", "DOWN", "LEFT"};
        for (int y = 0; y < TILE_ROWS; y++)
        {
            for (int x = 0; x < TILE_COLS; x++)
            {
                Pipe current = tileList[y][x];
                if (current == null)
                {
                    // Nope!
                }
                else
                {
                    for (String dir: DIRECTIONS)
                    {
                        if (current.getConnect(dir) == null)
                        {
                            // Well don't do stupid null stuff idiot
                        }
                        else if (current.getConnect(dir).getAllConnections().contains(current))
                        {
                            // I should never have been given the "gift" of "life".
                        }
                        else
                        {
                            current.setConnect(dir, null);
                        }
                    }
                }
            }
        }
    }

    public void drain()
    {
        for (int y = 0; y < tileList.length; y++)
        {
            for (int x = 0; x < tileList[y].length; x++)
            {
                if (tileList[y][x] == null)
                {
                    // Nothing
                }
                else if (tileList[y][x].getType().equals("SOURCE"))
                {
                    // Can't unfill sources
                }
                else
                {
                    tileList[y][x].setWater(false);
                }
            }
        }
    }

    public void createMenuBars()
    {
        // Define the menu bar
        menuBar = new JMenuBar();
        this.setJMenuBar(menuBar);

        // The Model menu
        menu = new JMenu("Model");
        menuBar.add(menu);
        menu.getPopupMenu().setLightWeightPopupEnabled(false); // Prevent Canvas overriding menu

        // Model : Quit
        menuItem = new JMenuItem("Quit");
        menuItem.addActionListener(this);
        menu.add(menuItem);
        // Model : Step 1 Frame
        menuItem = new JMenuItem("Step 1 Frame");
        menuItem.setAccelerator(KeyStroke.getKeyStroke('f')); // Only F key
        menuItem.addActionListener(this);
        menu.add(menuItem);
        // Edit : Drain
        menuItem = new JMenuItem("Drain");
        menuItem.addActionListener(this);
        menu.add(menuItem);

        // The UI menu
        menu = new JMenu("Interface");
        menuBar.add(menu);
        menu.getPopupMenu().setLightWeightPopupEnabled(false);
        // UI : Toggle Grid
        menuItem = new JMenuItem("Toggle Grid");
        menuItem.setAccelerator(KeyStroke.getKeyStroke('g'));
        menuItem.addActionListener(this);
        menu.add(menuItem);

        // The Edit menu
        menu = new JMenu("Edit");
        menuBar.add(menu);
        menu.getPopupMenu().setLightWeightPopupEnabled(false);
        // Edit : Reset
        menuItem = new JMenuItem("Reset");
        menuItem.addActionListener(this);
        menu.add(menuItem);
        // Edit : Pipe Selector
        menuItem = new JMenuItem("Pipe Selector");
        menuItem.setAccelerator(KeyStroke.getKeyStroke('s'));
        menuItem.addActionListener(this);
        menu.add(menuItem);
        // Edit : Eraser Mode
        menuItem = new JMenuItem("Eraser Mode");
        menuItem.setAccelerator(KeyStroke.getKeyStroke('e'));
        menuItem.addActionListener(this);
        menu.add(menuItem);
        // Edit : Rotate Left
        menuItem = new JMenuItem("Rotate Left");
        menuItem.setAccelerator(KeyStroke.getKeyStroke('z'));
        menuItem.addActionListener(this);
        menu.add(menuItem);
        // Edit : Rotate Right
        menuItem = new JMenuItem("Rotate Right");
        menuItem.setAccelerator(KeyStroke.getKeyStroke('x'));
        menuItem.addActionListener(this);
        menu.add(menuItem);
    }

    public void actionPerformed(ActionEvent evt)
    {
        String cmd = evt.getActionCommand();
        switch (cmd)
        {
            case "Quit":
                System.exit(0);
                break;
            case "Reset":
                tileList = new Pipe[TILE_ROWS][TILE_COLS];
                repaint();
                break;
            case "Step 1 Frame":
                updateFlow();
                repaint();
                break;
            case "Drain":
                drain();
                repaint();
                break;
            case "Toggle Grid":
                showGrid = 1 - showGrid;
                repaint();
                break;
            case "Pipe Selector":
                // open the pipe selector
                pipeSelector();
                repaint();
                break;
            case "Eraser Mode":
                editType = null;
                break;
            case "Rotate Left":
                // GO DIE YOU HORRIBLE PERSON!!!
                editDirection = (new String[]{"RIGHT", "DOWN", "LEFT", "UP"})["URDL".indexOf(editDirection.charAt(0))];
                repaint();
                break;
            case "Rotate Right":
                // And once again, DIE DIE DIE DIE DIE DIE BAD EVIL DIE!
                editDirection = (new String[]{"LEFT", "UP", "RIGHT", "DOWN"})["URDL".indexOf(editDirection.charAt(0))];
                repaint();
                // rotate right
                break;
            default:
                System.out.printf
                    (
                    "Invalid action detected. \nAt actionPerformed: Recieved evt \"%s\"",
                    evt
                    );
                break;
        }
    }
}
